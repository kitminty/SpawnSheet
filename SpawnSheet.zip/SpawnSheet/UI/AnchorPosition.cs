namespace SpawnSheet.UI
{
	internal enum AnchorPosition
	{
		Left,
		Right,
		Top,
		Bottom,
		Center,
		TopLeft,
		TopRight,
		BottomLeft,
		BottomRight
	}
}